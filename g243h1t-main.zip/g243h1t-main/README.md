# Dupla
## Sakai (03), Ryu (27)
